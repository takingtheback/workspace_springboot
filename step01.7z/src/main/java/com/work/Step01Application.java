package com.work;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Step01Application {

	public static void main(String[] args) {
		SpringApplication.run(Step01Application.class, args);
	}

}
